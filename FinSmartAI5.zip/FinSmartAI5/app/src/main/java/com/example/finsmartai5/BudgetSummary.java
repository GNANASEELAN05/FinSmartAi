package com.example.finsmartai5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BudgetSummary extends AppCompatActivity {
    private TextView tvBudgetSummary;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget_summary);

        tvBudgetSummary = findViewById(R.id.tv_budget_summary);
        sharedPreferences = getSharedPreferences("FinSmartPrefs", MODE_PRIVATE);

        displayBudgetSummary();
    }

    private void displayBudgetSummary() {
        int budget = sharedPreferences.getInt("budget", 0);
        int spent = calculateTotalExpenses();
        int remaining = budget - spent;

        String summary = "Total Budget: Rs." + budget + "\n" +
                "Total Spent: Rs." + spent + "\n" +
                "Remaining Budget: Rs." + remaining;

        tvBudgetSummary.setText(summary);
    }

    private int calculateTotalExpenses() {
        String savedExpenses = sharedPreferences.getString("expenses", "");
        int total = 0;

        if (!savedExpenses.isEmpty()) {
            for (String exp : savedExpenses.split(",")) {
                if (!exp.isEmpty()) {
                    try {
                        total += Integer.parseInt(exp);
                    } catch (NumberFormatException ignored) {
                        // Ignore invalid entries
                    }
                }
            }
        }
        return total;
    }
}
