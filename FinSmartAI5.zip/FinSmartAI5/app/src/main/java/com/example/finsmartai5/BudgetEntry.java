package com.example.finsmartai5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BudgetEntry extends AppCompatActivity {
    private EditText etBudgetAmount;
    private TextView tvRemainingBudget;
    private Button btnSaveBudget, btnClearBudget;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget_entry);

        // Initialize UI elements
        etBudgetAmount = findViewById(R.id.et_budget_amount);
        tvRemainingBudget = findViewById(R.id.tv_remaining_budget);
        btnSaveBudget = findViewById(R.id.btn_save_budget);
        btnClearBudget = findViewById(R.id.btn_clear_budget);

        sharedPreferences = getSharedPreferences("FinSmartPrefs", MODE_PRIVATE);

        // Load and display budget info
        loadBudget();

        // Button listeners
        btnSaveBudget.setOnClickListener(v -> saveBudget());
        btnClearBudget.setOnClickListener(v -> clearBudget());
    }

    private void saveBudget() {
        String input = etBudgetAmount.getText().toString().trim();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a budget amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int budget = Integer.parseInt(input);
            if (budget < 0) {
                Toast.makeText(this, "Budget cannot be negative", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save budget to SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("budget", budget);
            editor.apply();

            loadBudget(); // Refresh UI
            Toast.makeText(this, "Budget saved successfully!", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid numeric amount", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadBudget() {
        int budget = sharedPreferences.getInt("budget", 0);
        int spent = calculateTotalExpenses();
        int remaining = budget - spent;

        tvRemainingBudget.setText("Remaining Budget: Rs." + remaining);
    }

    private int calculateTotalExpenses() {
        String savedExpenses = sharedPreferences.getString("expenses", "");
        int total = 0;

        if (!savedExpenses.isEmpty()) {
            for (String exp : savedExpenses.split(",")) {
                if (!exp.isEmpty()) {
                    try {
                        total += Integer.parseInt(exp);
                    } catch (NumberFormatException ignored) {
                        // Ignore invalid entries
                    }
                }
            }
        }
        return total;
    }

    private void clearBudget() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("budget");
        editor.apply();

        tvRemainingBudget.setText("Remaining Budget: Rs.0");
        etBudgetAmount.setText("");

        Toast.makeText(this, "Budget cleared successfully!", Toast.LENGTH_SHORT).show();
    }
}
