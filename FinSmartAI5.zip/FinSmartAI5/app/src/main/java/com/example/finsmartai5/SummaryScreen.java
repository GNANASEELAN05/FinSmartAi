package com.example.finsmartai5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SummaryScreen extends AppCompatActivity {

    private TextView tvTotalBudget, tvTotalExpenses, tvRemainingBudget;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_screen);

        tvTotalBudget = findViewById(R.id.tv_total_budget);
        tvTotalExpenses = findViewById(R.id.tv_total_expenses);
        tvRemainingBudget = findViewById(R.id.tv_remaining_budget);

        sharedPreferences = getSharedPreferences("FinSmartPrefs", MODE_PRIVATE);
        displaySummary();
    }

    private void displaySummary() {
        int totalBudget = sharedPreferences.getInt("budget", 0);
        int totalExpenses = calculateTotalExpenses();
        int remainingBudget = totalBudget - totalExpenses;

        tvTotalBudget.setText("Total Budget: Rs." + totalBudget);
        tvTotalExpenses.setText("Total Expenses: Rs." + totalExpenses);
        tvRemainingBudget.setText("Remaining Budget: Rs." + remainingBudget);
    }

    private int calculateTotalExpenses() {
        String savedExpenses = sharedPreferences.getString("expenses", "");
        int total = 0;
        if (!savedExpenses.isEmpty()) {
            for (String exp : savedExpenses.split(",")) {
                if (!exp.isEmpty()) {
                    total += Integer.parseInt(exp);
                }
            }
        }
        return total;
    }
}
