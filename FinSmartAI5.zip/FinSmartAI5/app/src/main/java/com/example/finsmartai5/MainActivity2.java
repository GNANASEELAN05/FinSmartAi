package com.example.finsmartai5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private EditText amountInput;
    private Button btnSaveExpense, btnPredict, btnDeleteExpenses;
    private Button btnSavingsCalculator, btnExpenseTracker, btnBudgetEntry, btnBudgetSummary;
    private TextView expenseList;
    private List<Integer> expenses;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Initialize UI elements
        amountInput = findViewById(R.id.et_budget_amount);
        btnSaveExpense = findViewById(R.id.btn_save_expense);
        btnPredict = findViewById(R.id.btn_predict);
        btnDeleteExpenses = findViewById(R.id.btn_delete_expenses);
        expenseList = findViewById(R.id.tv_expense_list);

        // Navigation Buttons
        btnSavingsCalculator = findViewById(R.id.btn_savings_calculator);
        btnExpenseTracker = findViewById(R.id.btn_expense_tracker);
        btnBudgetEntry = findViewById(R.id.btn_budget_entry);
        btnBudgetSummary = findViewById(R.id.btn_budget_summary);

        // Initialize SharedPreferences and Load Expenses
        sharedPreferences = getSharedPreferences("FinSmartPrefs", MODE_PRIVATE);
        expenses = new ArrayList<>();
        loadExpenses();

        // Button Listeners
        btnSaveExpense.setOnClickListener(v -> saveExpense());
        btnPredict.setOnClickListener(v -> predictExpenses());
        btnDeleteExpenses.setOnClickListener(v -> deleteExpenses());

        // Navigation Button Listeners
        btnSavingsCalculator.setOnClickListener(v -> openActivity(SavingsCalculator.class));
        btnExpenseTracker.setOnClickListener(v -> openActivity(ExpenseTracker.class));
        btnBudgetEntry.setOnClickListener(v -> openActivity(BudgetEntry.class));
        btnBudgetSummary.setOnClickListener(v -> openActivity(BudgetSummary.class));
    }

    private void openActivity(Class<?> activityClass) {
        startActivity(new Intent(MainActivity2.this, activityClass));
    }

    private void saveExpense() {
        String input = amountInput.getText().toString().trim();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter an expense amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int amount = Integer.parseInt(input);
            if (amount < 0) {
                Toast.makeText(this, "Expense cannot be negative", Toast.LENGTH_SHORT).show();
                return;
            }

            expenses.add(amount);
            saveToPreferences();
            displayExpenses();
            amountInput.setText("");

            Toast.makeText(this, "Expense saved successfully!", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid numeric amount", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveToPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        StringBuilder expenseString = new StringBuilder();
        for (int exp : expenses) {
            expenseString.append(exp).append(",");
        }
        editor.putString("expenses", expenseString.toString());
        editor.apply();
    }

    private void loadExpenses() {
        String savedExpenses = sharedPreferences.getString("expenses", "");
        if (!savedExpenses.isEmpty()) {
            String[] expenseArray = savedExpenses.split(",");
            for (String exp : expenseArray) {
                if (!exp.isEmpty()) {
                    try {
                        expenses.add(Integer.parseInt(exp));
                    } catch (NumberFormatException ignored) {
                        // Ignore invalid data
                    }
                }
            }
            displayExpenses();
        }
    }

    private void displayExpenses() {
        if (expenses.isEmpty()) {
            expenseList.setText("No expenses recorded.");
            return;
        }

        StringBuilder displayText = new StringBuilder("Expenses:\n");
        for (int exp : expenses) {
            displayText.append("Rs.").append(exp).append("\n");
        }
        expenseList.setText(displayText.toString());
    }

    private void predictExpenses() {
        if (expenses.isEmpty()) {
            expenseList.setText("No expenses to predict.");
            return;
        }

        int total = 0;
        for (int exp : expenses) {
            total += exp;
        }
        int avgExpense = total / expenses.size();
        int predictedMonthlyExpense = avgExpense * 30;

        expenseList.append("\nPredicted Future Expense: Rs." + predictedMonthlyExpense + " (monthly estimate)");
    }

    private void deleteExpenses() {
        expenses.clear();
        sharedPreferences.edit().remove("expenses").apply();
        expenseList.setText("Expenses cleared.");
        Toast.makeText(this, "All expenses deleted!", Toast.LENGTH_SHORT).show();
    }
}
