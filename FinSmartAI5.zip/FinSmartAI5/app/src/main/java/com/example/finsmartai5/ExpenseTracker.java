package com.example.finsmartai5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ExpenseTracker extends AppCompatActivity {
    private ListView listViewExpenses;
    private Button btnClearExpenses;
    private TextView tvNoExpenses;
    private List<String> expensesList;
    private ArrayAdapter<String> adapter;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_tracker);

        listViewExpenses = findViewById(R.id.list_expenses);
        btnClearExpenses = findViewById(R.id.btn_clear_expenses);
        tvNoExpenses = findViewById(R.id.tv_no_expenses); // New text view to show when no expenses exist
        sharedPreferences = getSharedPreferences("FinSmartPrefs", MODE_PRIVATE);

        loadExpenses();

        btnClearExpenses.setOnClickListener(v -> clearExpenses());
    }

    private void loadExpenses() {
        String savedExpenses = sharedPreferences.getString("expenses", "");
        if (!savedExpenses.isEmpty()) {
            expensesList = new ArrayList<>(Arrays.asList(savedExpenses.split(",")));
        } else {
            expensesList = new ArrayList<>();
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expensesList);
        listViewExpenses.setAdapter(adapter);

        updateExpenseVisibility();
    }

    private void clearExpenses() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("expenses"); // Clear saved expenses
        editor.apply();

        expensesList.clear();
        adapter.notifyDataSetChanged();
        updateExpenseVisibility();
        Toast.makeText(this, "All expenses deleted!", Toast.LENGTH_SHORT).show();
    }

    private void updateExpenseVisibility() {
        if (expensesList.isEmpty()) {
            tvNoExpenses.setVisibility(View.VISIBLE);
            listViewExpenses.setVisibility(View.GONE);
        } else {
            tvNoExpenses.setVisibility(View.GONE);
            listViewExpenses.setVisibility(View.VISIBLE);
        }
    }
}
