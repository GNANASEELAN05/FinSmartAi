package com.example.finsmartai5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SavingsCalculator extends AppCompatActivity {
    private EditText incomeInput, expenseInput;
    private Button btnCalculateSavings, btnClear;
    private TextView savingsResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savings_calculator);

        incomeInput = findViewById(R.id.et_income);
        expenseInput = findViewById(R.id.et_expense);
        btnCalculateSavings = findViewById(R.id.btn_calculate_savings);
        btnClear = findViewById(R.id.btn_clear_inputs);
        savingsResult = findViewById(R.id.tv_savings_result);

        btnCalculateSavings.setOnClickListener(v -> calculateSavings());
        btnClear.setOnClickListener(v -> clearInputs());
    }

    private void calculateSavings() {
        String incomeStr = incomeInput.getText().toString().trim();
        String expenseStr = expenseInput.getText().toString().trim();

        if (incomeStr.isEmpty() || expenseStr.isEmpty()) {
            Toast.makeText(this, "Please enter both income and expense.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int income = Integer.parseInt(incomeStr);
            int expenses = Integer.parseInt(expenseStr);
            int savings = income - expenses;

            if (savings < 0) {
                savingsResult.setText("Warning: Your expenses exceed your income!");
            } else {
                savingsResult.setText("Your Savings: Rs." + savings);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numeric values.", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInputs() {
        incomeInput.setText("");
        expenseInput.setText("");
        savingsResult.setText("");
    }
}
